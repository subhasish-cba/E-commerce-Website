from flask import Flask, render_template, redirect, url_for, request, flash
from db_models import db, Item, Customer, CartItem
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///green_shop.db'
app.config['SECRET_KEY'] = 'your_new_secret_key'
db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'user_login'

@login_manager.user_loader
def fetch_user(user_id):
    return Customer.query.get(int(user_id))

@app.route('/')
def index():
    products = Item.query.all()
    return render_template('index.html', products=products)

@app.route('/product/<int:product_id>')
def item_detail(product_id):
    product = Item.query.get_or_404(product_id)
    return render_template('item_detail.html', product=product)

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
@login_required
def add_to_user_cart(product_id):
    product = Item.query.get(product_id)
    if product:
        cart_entry = CartItem(buyer_id=current_user.customer_id, item_id=product_id, quantity=1)
        db.session.add(cart_entry)
        db.session.commit()
        flash('Item successfully added to cart!')
    return redirect(url_for('index'))

@app.route('/user_cart')
@login_required
def user_cart():
    cart_items = CartItem.query.filter_by(buyer_id=current_user.customer_id).all()
    return render_template('user_cart.html', cart_items=cart_items)

@app.route('/user_login', methods=['GET', 'POST'])
def user_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = Customer.query.filter_by(customer_email=email).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Login unsuccessful. Check your email and password.')
    return render_template('user_login.html')

@app.route('/logout')
@login_required
def user_logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
